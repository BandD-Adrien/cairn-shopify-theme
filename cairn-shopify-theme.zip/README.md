# Thème Shopify Cairn

## Upload
Admin Shopify → Boutique en ligne → Thèmes → Ajouter un thème → **Télécharger le fichier ZIP**.

## Utilisation
1. Une fois uploadé, clique *Personnaliser* ou *Publier*.
2. Admin → *Pages* → *Ajouter une page*
3. Titre : "Cairn"
4. Dans le panneau de droite, *Modèle de thème* → sélectionne **page.cairn**
5. Publie. La page est à `/pages/cairn`.

## Brancher le bouton Précommander
Dans l'éditeur de code : `sections/cairn-landing.liquid` — remplace `href="#precommande"` par l'URL de ta page produit, par exemple `/products/cairn`.

## Notes
- Thème minimaliste conçu uniquement pour héberger la landing Cairn.
- Les pages produit/collection/panier ont un rendu basique — à remplacer par un vrai thème si tu vends d'autres produits.
